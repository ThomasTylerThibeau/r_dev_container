test_that("minmax returns a vector len 2", {
  expect_length(minmax(1:10), 2)
})
