minmax <- function(x, ...){
  c(Min = min(x, ...), Max = max(x, ...))
}
## basic function that is seen as a dependency of others
## ... allows the user to add their own arguments
