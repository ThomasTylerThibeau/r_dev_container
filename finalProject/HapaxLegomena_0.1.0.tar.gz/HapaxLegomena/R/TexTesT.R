#' Example text to run functions with.
#'
#' @format text
#'
#' @examples
#'  data(TexTesT) # lazy load, 'cause, you know...
"TexTesT"
