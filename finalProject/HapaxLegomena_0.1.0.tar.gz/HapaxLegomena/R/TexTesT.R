#' This is pretty much just a text file with a back story for the curious.
#' It exists entirely to test the functions out and see how they behave.
#'
#' @format text
#'
#' @example data(TexTesT)
"TexTesT"
