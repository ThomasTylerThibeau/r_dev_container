#' @title slopeFunc
#' @description Finds the slope of a line with one or two x, y, z points
#' @name slope
#' @doctype idk
#' @usage idk
#' @format idk
#' @keywords slope

