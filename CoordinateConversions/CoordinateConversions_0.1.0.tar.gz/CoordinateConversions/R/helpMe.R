r = 4
r+= 4
r

newConsole()
